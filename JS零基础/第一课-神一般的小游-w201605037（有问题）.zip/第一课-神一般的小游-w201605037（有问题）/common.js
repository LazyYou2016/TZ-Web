//引入外部js文件，在当前html文件调用并输出——S
function demo2_Text(){
	document.getElementById('demo3').innerText = 'Hello World~'
}
//引入外部js文件，在当前html文件调用并输出——E